/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.revenuecat.purchases.api;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.revenuecat.purchases.api";
  public static final String BUILD_TYPE = "release";
  public static final String FLAVOR = "defaultsBc8";
  public static final String FLAVOR_apis = "defaults";
  public static final String FLAVOR_billingclient = "bc8";
  // Field from product flavor: bc8
  public static final String BILLING_CLIENT_VERSION = "8.3.0";
  // Field from default config.
  public static final boolean ENABLE_EXTRA_REQUEST_LOGGING = false;
  // Field from default config.
  public static final String SAMSUNG_IAP_SDK_VERSION = "6.5.0";
}
