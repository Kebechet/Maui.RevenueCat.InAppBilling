package com.revenuecat.purchases

/**
 * Specifies the user consent status for Login with Amazon
 */
public enum class AmazonLWAConsentStatus {
    /**
     * User has provided consent to access data.
     */
    CONSENTED,

    /**
     * User hasn't provided consent or the consent has expired.
     */
    UNAVAILABLE,
}
