package com.revenuecat.purchases.common

import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.PurchasesError
import com.revenuecat.purchases.PurchasesErrorCode
import com.revenuecat.purchases.common.networking.HTTPResult
import com.revenuecat.purchases.common.networking.NullPointerReadingErrorStreamException
import com.revenuecat.purchases.common.verification.SignatureVerificationException
import org.json.JSONException
import java.io.IOException

@SuppressWarnings("MagicNumber")
internal enum class BackendErrorCode(val value: Int) {
    BackendInvalidPlatform(7000),
    BackendStoreProblem(7101),
    BackendCannotTransferPurchase(7102),
    BackendInvalidReceiptToken(7103),
    BackendInvalidAppStoreSharedSecret(7104),
    BackendInvalidPaymentModeOrIntroPriceNotProvided(7105),
    BackendProductIdForGoogleReceiptNotProvided(7106),
    BackendInvalidPlayStoreCredentials(7107),
    BackendInternalServerError(7110),
    BackendEmptyAppUserId(7220),
    BackendInvalidAuthToken(7224),
    BackendInvalidAPIKey(7225),
    BackendBadRequest(7226),
    BackendPlayStoreQuotaExceeded(7229),
    BackendPlayStoreInvalidPackageName(7230),
    BackendPlayStoreGenericError(7231),
    BackendUserIneligibleForPromoOffer(7232),
    BackendInvalidAppleSubscriptionKey(7234),
    BackendCouldNotCreateAlias(7255),
    BackendInvalidAppUserId(7256),
    BackendInvalidSubscriberAttributes(7263),
    BackendInvalidSubscriberAttributesBody(7264),
    BackendSubscriberAttributesAreBeingUpdated(7629),
    BackendPaymentNotComplete(7651),
    BackendRequestAlreadyInProgress(7638),
    BackendProductIDsMalformed(7662),
    BackendInvalidWebRedemptionToken(7849),
    BackendPurchaseBelongsToOtherUser(7852),
    BackendExpiredWebRedemptionToken(7853),
    ;

    companion object {
        fun valueOf(backendErrorCode: Int): BackendErrorCode? {
            return values().firstOrNull { it.value == backendErrorCode }
        }
    }
}

internal fun Exception.toPurchasesError(): PurchasesError {
    return when (this) {
        is JSONException, is IOException -> {
            PurchasesError(PurchasesErrorCode.NetworkError, localizedMessage)
        }
        is SecurityException -> {
            PurchasesError(PurchasesErrorCode.InsufficientPermissionsError, localizedMessage)
        }
        is SignatureVerificationException -> {
            PurchasesError(PurchasesErrorCode.SignatureVerificationError, localizedMessage)
        }
        is NullPointerReadingErrorStreamException -> {
            PurchasesError(
                PurchasesErrorCode.UnknownError,
                "In some devices, there seems to be an error when trying to parse the error response. " +
                    "Original error message: ${cause?.localizedMessage ?: localizedMessage}",
            )
        }
        else -> PurchasesError(PurchasesErrorCode.UnknownError, localizedMessage)
    }
}

private fun BackendErrorCode.toPurchasesError(underlyingErrorMessage: String) =
    PurchasesError(this.toPurchasesErrorCode(), underlyingErrorMessage)

@OptIn(InternalRevenueCatAPI::class)
internal fun HTTPResult.toPurchasesError(): PurchasesError {
    val errorCode = backendErrorCode
    val errorMessage = backendErrorMessage ?: ""

    return errorCode?.let { BackendErrorCode.valueOf(it) }?.toPurchasesError(errorMessage)
        ?: PurchasesError(
            PurchasesErrorCode.UnknownBackendError,
            "Backend Code: ${errorCode ?: "N/A"} - $errorMessage",
        )
}

@Suppress("ComplexMethod")
private fun BackendErrorCode.toPurchasesErrorCode(): PurchasesErrorCode {
    return when (this) {
        BackendErrorCode.BackendStoreProblem -> PurchasesErrorCode.StoreProblemError
        BackendErrorCode.BackendCannotTransferPurchase -> PurchasesErrorCode.ReceiptAlreadyInUseError
        BackendErrorCode.BackendInvalidReceiptToken -> PurchasesErrorCode.InvalidReceiptError
        BackendErrorCode.BackendInvalidPlayStoreCredentials,
        BackendErrorCode.BackendInvalidAuthToken,
        BackendErrorCode.BackendInvalidAPIKey,
        -> PurchasesErrorCode.InvalidCredentialsError
        BackendErrorCode.BackendInvalidPaymentModeOrIntroPriceNotProvided,
        BackendErrorCode.BackendProductIdForGoogleReceiptNotProvided,
        -> PurchasesErrorCode.PurchaseInvalidError
        BackendErrorCode.BackendEmptyAppUserId,
        BackendErrorCode.BackendInvalidAppUserId,
        -> PurchasesErrorCode.InvalidAppUserIdError
        BackendErrorCode.BackendPlayStoreQuotaExceeded -> PurchasesErrorCode.StoreProblemError
        BackendErrorCode.BackendPlayStoreInvalidPackageName,
        BackendErrorCode.BackendInvalidPlatform,
        -> PurchasesErrorCode.ConfigurationError
        BackendErrorCode.BackendPlayStoreGenericError -> PurchasesErrorCode.StoreProblemError
        BackendErrorCode.BackendUserIneligibleForPromoOffer -> PurchasesErrorCode.IneligibleError
        BackendErrorCode.BackendInvalidSubscriberAttributes,
        BackendErrorCode.BackendInvalidSubscriberAttributesBody,
        -> PurchasesErrorCode.InvalidSubscriberAttributesError
        BackendErrorCode.BackendInvalidAppStoreSharedSecret,
        BackendErrorCode.BackendInvalidAppleSubscriptionKey,
        BackendErrorCode.BackendBadRequest,
        BackendErrorCode.BackendInternalServerError,
        -> PurchasesErrorCode.UnexpectedBackendResponseError
        BackendErrorCode.BackendRequestAlreadyInProgress,
        BackendErrorCode.BackendSubscriberAttributesAreBeingUpdated,
        -> PurchasesErrorCode.OperationAlreadyInProgressError
        BackendErrorCode.BackendPaymentNotComplete -> PurchasesErrorCode.PaymentPendingError
        BackendErrorCode.BackendCouldNotCreateAlias -> PurchasesErrorCode.ConfigurationError
        BackendErrorCode.BackendProductIDsMalformed -> PurchasesErrorCode.UnsupportedError
        BackendErrorCode.BackendInvalidWebRedemptionToken -> PurchasesErrorCode.PurchaseInvalidError
        BackendErrorCode.BackendPurchaseBelongsToOtherUser -> PurchasesErrorCode.ProductAlreadyPurchasedError
        BackendErrorCode.BackendExpiredWebRedemptionToken -> PurchasesErrorCode.PurchaseInvalidError
    }
}

internal data class SubscriberAttributeError(
    val keyName: String,
    val message: String,
)
