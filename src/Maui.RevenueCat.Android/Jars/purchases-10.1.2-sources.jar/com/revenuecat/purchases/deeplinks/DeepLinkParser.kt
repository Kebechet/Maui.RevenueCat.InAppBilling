package com.revenuecat.purchases.deeplinks

import android.net.Uri
import com.revenuecat.purchases.WebPurchaseRedemption
import com.revenuecat.purchases.common.debugLog

internal object DeepLinkParser {
    private const val REDEEM_WEB_PURCHASE_HOST = "redeem_web_purchase"

    fun parseWebPurchaseRedemption(data: Uri): WebPurchaseRedemption? {
        return if (data.host == REDEEM_WEB_PURCHASE_HOST) {
            val redemptionToken = data.getQueryParameter("redemption_token")
            if (redemptionToken.isNullOrBlank()) {
                debugLog { "Redemption token is missing web redemption deep link. Ignoring." }
                null
            } else {
                WebPurchaseRedemption(redemptionToken)
            }
        } else {
            debugLog { "Unrecognized deep link host: ${data.host}. Ignoring" }
            null
        }
    }
}
